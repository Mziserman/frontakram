var gulp = require('gulp');
var concat = require('gulp-concat');
var browserSync = require('browser-sync').create();
var watch = require('gulp-watch');
var reload = browserSync.reload

gulp.task('default', function(){

	browserSync.init({
        proxy: "http://localhost:8888/HETIC/annee_3/front_end/app-start/"
    });
	gulp.watch('js/**', ['js_app']);
	gulp.watch('js/**').on('change', reload);
});

gulp.task('js_app', function(){

	return gulp.src('js/app/**/*.js')
		.pipe(concat('app.js'))
		.pipe(gulp.dest('js/dist/'));


});


gulp.task('say_hi', function(){
	console.log('hi');
})