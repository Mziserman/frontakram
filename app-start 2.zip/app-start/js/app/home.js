$(document).ready(function(){
	console.log('coooooooo');
	var home = $('#home');
	var movie = $('#the-movie');
	
	$('#home .cta').on('click', function(e){
		e.preventDefault();
	
		home.fadeOut();
		movie.fadeIn(function(){
			$('#the-movie .content').addClass('visible');
			setTimeout(function(){
				$('#the-movie .cta').fadeIn();
			}, 200);
		});
	
	})
})