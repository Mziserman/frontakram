$(document).ready(function(){
	alert('kiki');
	var movie = $('#the-movie');
	var header = $('header');
	var trailer = $('#trailer');
	var video = $('#trailer video')[0];

	movie.find('.cta').on('click', function(e){
		e.preventDefault();

		movie.fadeOut();
		header.fadeOut()

		trailer.fadeIn(function(){
			video.play();
		});
	})
})